<!--begin::Header-->
<nav class="app-header navbar navbar-expand bg-body">
  <!--begin::Container-->
  <div class="container-fluid">
    <!--begin::Start Navbar Links-->
    <ul class="navbar-nav">
      <li class="nav-item">
        <a class="nav-link" data-lte-toggle="sidebar" href="#" role="button">
          <i class="bi bi-list"></i>
        </a>
      </li>
    </ul>
    <!--end::Start Navbar Links-->
    <!--begin::End Navbar Links-->
    <ul class="navbar-nav ms-auto">
      <li class="nav-item">
        <a class="nav-link" href="<?= BASE_URL ?>cart">
          <i class="bi bi-cart3"></i>
          <span class="navbar-badge badge text-bg-warning"><?= cartCount() ?></span>
        </a>
      </li>
      <!--begin::Fullscreen Toggle-->
      <li class="nav-item">
        <a class="nav-link" href="#" data-lte-toggle="fullscreen">
          <i data-lte-icon="maximize" class="bi bi-arrows-fullscreen"></i>
          <i data-lte-icon="minimize" class="bi bi-fullscreen-exit" style="display: none"></i>
        </a>
      </li>
      <!--end::Fullscreen Toggle-->
      <!--begin::User Menu Dropdown-->
      <?php if (isLoggedIn()): ?>
        <?php $currentUser = getCurrentUser(); ?>
        <li class="nav-item dropdown user-menu">
          <a href="#" class="nav-link dropdown-toggle" data-bs-toggle="dropdown">
            <img
              src="<?= asset('dist/assets/img/user2-160x160.jpg') ?>"
              class="user-image rounded-circle shadow"
              alt="User Image"
            />
            <span class="d-none d-md-inline"><?= $currentUser->name ?></span>
          </a>
          <ul class="dropdown-menu dropdown-menu-lg dropdown-menu-end">
            <!--begin::User Image-->
            <li class="user-header text-bg-primary">
              <img
                src="<?= asset('dist/assets/img/user2-160x160.jpg') ?>"
                class="rounded-circle shadow"
                alt="User Image"
              />
              <p>
              <?= $currentUser->isAdmin() ? 'Quản trị viên' : 'Khách hàng' ?>                <small><?= date('M. Y') ?></small>
              </p>
            </li>
            <!--end::User Image-->
            <!--begin::Menu Body-->
            
            <!--end::Menu Body-->
            <!--begin::Menu Footer-->
            <li class="user-footer">
              <a href="#" class="btn btn-default btn-flat">Tài khoản</a>
              <a href="<?= BASE_URL . 'logout' ?>" class="btn btn-default btn-flat float-end">Đăng xuất</a>
            </li>
            <!--end::Menu Footer-->
          </ul>
        </li>
      <?php endif; ?>
      <!--end::User Menu Dropdown-->
    </ul>
    <!--end::End Navbar Links-->
  </div>
  <!--end::Container-->
</nav>
<!--end::Header-->

